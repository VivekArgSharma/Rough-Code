import React, { useState, useCallback } from 'react';
import CodeEditor from './components/CodeEditor';
import OutputPanel from './components/OutputPanel';
import DrawingCanvas from './components/DrawingCanvas';
import LargeDrawingCanvas from './components/LargeDrawingCanvas';
import { executeCode, languages } from './services/pistonApi';
import { Language } from './types';
import { Code, ChevronDown } from 'lucide-react';

export default function App() {
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(languages[0]);
  const [code, setCode] = useState<string>(selectedLanguage.template);
  const [output, setOutput] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [executionTime, setExecutionTime] = useState<number | undefined>();

  const handleLanguageChange = useCallback((language: Language) => {
    setSelectedLanguage(language);
    setCode(language.template);
    setOutput('');
    setError('');
  }, []);

  const handleExecuteCode = useCallback(async () => {
    if (!code.trim()) return;

    setIsExecuting(true);
    setOutput('');
    setError('');
    
    const startTime = Date.now();
    
    try {
      const result = await executeCode(selectedLanguage.id, selectedLanguage.version, code);
      const endTime = Date.now();
      
      setExecutionTime(endTime - startTime);
      setOutput(result.run.output || '');
      setError(result.run.stderr || '');
    } catch (err) {
      const endTime = Date.now();
      setExecutionTime(endTime - startTime);
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsExecuting(false);
    }
  }, [code, selectedLanguage]);

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Header */}
      <header className="bg-gray-900 border-b border-gray-700 px-6 py-4">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <Code className="w-8 h-8 text-blue-400" />
            <h1 className="text-2xl font-bold text-white">Rough + Code</h1>
          </div>
          <span className="text-gray-400">•</span>
          <p className="text-gray-400">Do your rough work while coding</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-140px)]">
          {/* Code Editor */}
          <div className="lg:col-span-1">
            <CodeEditor
              code={code}
              language={selectedLanguage}
              languages={languages}
              isExecuting={isExecuting}
              onCodeChange={(value) => setCode(value || '')}
              onLanguageChange={handleLanguageChange}
              onExecute={handleExecuteCode}
            />
          </div>

          {/* Output Panel */}
          <div className="lg:col-span-1">
            <OutputPanel
              output={output}
              error={error}
              isExecuting={isExecuting}
              executionTime={executionTime}
            />
          </div>

          {/* Drawing Canvas */}
          <div className="lg:col-span-1">
            <DrawingCanvas />
          </div>
        </div>
      </main>

      {/* Scroll Indicator */}
      <div className="flex justify-center py-4 bg-gray-950">
        <div className="flex items-center space-x-2 text-gray-500">
          <ChevronDown className="w-4 h-4 animate-bounce" />
          <span className="text-sm">Scroll down for larger drawing workspace</span>
          <ChevronDown className="w-4 h-4 animate-bounce" />
        </div>
      </div>

      {/* Large Drawing Section */}
      <section className="bg-gray-950 px-6 py-8">
        <LargeDrawingCanvas />
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-700 px-6 py-4">
        <div className="text-center text-gray-500 text-sm">
          <p>Rough + Code - One Stop solution for rough and code</p>
        </div>
      </footer>
    </div>
  );
}