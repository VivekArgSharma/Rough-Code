import React from 'react';
import Editor from '@monaco-editor/react';
import { Play, Square } from 'lucide-react';
import { Language } from '../types';

interface CodeEditorProps {
  code: string;
  language: Language;
  languages: Language[];
  isExecuting: boolean;
  onCodeChange: (value: string | undefined) => void;
  onLanguageChange: (language: Language) => void;
  onExecute: () => void;
}

export default function CodeEditor({
  code,
  language,
  languages,
  isExecuting,
  onCodeChange,
  onLanguageChange,
  onExecute,
}: CodeEditorProps) {
  return (
    <div className="flex flex-col h-full bg-gray-900 border border-gray-700 rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-3 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <select
            value={language.id}
            onChange={(e) => {
              const selectedLang = languages.find(lang => lang.id === e.target.value);
              if (selectedLang) onLanguageChange(selectedLang);
            }}
            className="bg-gray-700 text-white px-3 py-1.5 rounded text-sm border border-gray-600 focus:outline-none focus:border-blue-400"
          >
            {languages.map((lang) => (
              <option key={lang.id} value={lang.id}>
                {lang.name}
              </option>
            ))}
          </select>
          <span className="text-xs text-gray-400">v{language.version}</span>
        </div>
        <button
          onClick={onExecute}
          disabled={isExecuting}
          className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white px-4 py-1.5 rounded text-sm transition-colors"
        >
          {isExecuting ? (
            <>
              <Square className="w-4 h-4" />
              <span>Running...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              <span>Run</span>
            </>
          )}
        </button>
      </div>

      {/* Editor */}
      <div className="flex-1">
        <Editor
          height="100%"
          defaultLanguage={language.id === 'cpp' ? 'cpp' : language.id}
          language={language.id === 'cpp' ? 'cpp' : language.id}
          value={code}
          onChange={onCodeChange}
          theme="vs-dark"
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            wordWrap: 'on',
            automaticLayout: true,
            scrollBeyondLastLine: false,
            padding: { top: 16 },
          }}
        />
      </div>
    </div>
  );
}