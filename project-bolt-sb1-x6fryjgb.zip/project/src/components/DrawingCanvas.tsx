import React, { useRef, useEffect, useState } from 'react';
import { Pen, Eraser, Square, Circle, Minus, Palette, RotateCcw, Download } from 'lucide-react';
import { DrawingTool } from '../types';

export default function DrawingCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<DrawingTool>({
    type: 'pen',
    size: 2,
    color: '#ffffff'
  });

  const colors = [
    '#ffffff', '#000000', '#ff0000', '#00ff00', '#0000ff',
    '#ffff00', '#ff00ff', '#00ffff', '#ffa500', '#800080'
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Set initial canvas background
    ctx.fillStyle = '#1f2937';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  const startDrawing = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setIsDrawing(true);
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (tool.type === 'pen' || tool.type === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };

  const draw = (e: React.MouseEvent) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineWidth = tool.size;
    ctx.lineCap = 'round';

    if (tool.type === 'pen') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = tool.color;
      ctx.lineTo(x, y);
      ctx.stroke();
    } else if (tool.type === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#1f2937';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const downloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = 'drawing.png';
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 border border-gray-700 rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-3 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <Palette className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-300">Drawing Pad</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={clearCanvas}
            className="text-gray-400 hover:text-white p-1 rounded transition-colors"
            title="Clear Canvas"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={downloadCanvas}
            className="text-gray-400 hover:text-white p-1 rounded transition-colors"
            title="Download Canvas"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="p-3 bg-gray-800 border-b border-gray-700">
        <div className="space-y-3">
          {/* Tools */}
          <div className="flex items-center space-x-2">
            <span className="text-xs text-gray-400 w-12">Tools:</span>
            <div className="flex space-x-1">
              {[
                { type: 'pen' as const, icon: Pen, label: 'Pen' },
                { type: 'eraser' as const, icon: Eraser, label: 'Eraser' },
              ].map(({ type, icon: Icon, label }) => (
                <button
                  key={type}
                  onClick={() => setTool(prev => ({ ...prev, type }))}
                  className={`p-1.5 rounded text-xs transition-colors ${
                    tool.type === type
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                  title={label}
                >
                  <Icon className="w-3 h-3" />
                </button>
              ))}
            </div>
          </div>

          {/* Size */}
          <div className="flex items-center space-x-2">
            <span className="text-xs text-gray-400 w-12">Size:</span>
            <input
              type="range"
              min="1"
              max="20"
              value={tool.size}
              onChange={(e) => setTool(prev => ({ ...prev, size: parseInt(e.target.value) }))}
              className="flex-1 h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-xs text-gray-400 w-6">{tool.size}</span>
          </div>

          {/* Colors */}
          <div className="flex items-center space-x-2">
            <span className="text-xs text-gray-400 w-12">Color:</span>
            <div className="flex space-x-1">
              {colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setTool(prev => ({ ...prev, color }))}
                  className={`w-6 h-6 rounded border-2 transition-all ${
                    tool.color === color ? 'border-blue-400 scale-110' : 'border-gray-600'
                  }`}
                  style={{ backgroundColor: color }}
                  title={color}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 relative">
        <canvas
          ref={canvasRef}
          className="w-full h-full cursor-crosshair"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
        />
      </div>
    </div>
  );
}