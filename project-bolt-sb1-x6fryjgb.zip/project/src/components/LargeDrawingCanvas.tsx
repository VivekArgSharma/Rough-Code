import React, { useRef, useEffect, useState } from 'react';
import { Pen, Eraser, Square, Circle, Minus, Palette, RotateCcw, Download, Maximize2 } from 'lucide-react';
import { DrawingTool } from '../types';

export default function LargeDrawingCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<DrawingTool>({
    type: 'pen',
    size: 3,
    color: '#ffffff'
  });

  const colors = [
    '#ffffff', '#000000', '#ff0000', '#00ff00', '#0000ff',
    '#ffff00', '#ff00ff', '#00ffff', '#ffa500', '#800080',
    '#ff69b4', '#32cd32', '#87ceeb', '#dda0dd', '#f0e68c'
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size to be larger
    canvas.width = canvas.offsetWidth;
    canvas.height = 600; // Fixed height for large canvas

    // Set initial canvas background
    ctx.fillStyle = '#1f2937';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  const startDrawing = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setIsDrawing(true);
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (tool.type === 'pen' || tool.type === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };

  const draw = (e: React.MouseEvent) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineWidth = tool.size;
    ctx.lineCap = 'round';

    if (tool.type === 'pen') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = tool.color;
      ctx.lineTo(x, y);
      ctx.stroke();
    } else if (tool.type === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#1f2937';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const downloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = 'algorithm-sketch.png';
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div className="bg-gray-900 border border-gray-700 rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <Maximize2 className="w-5 h-5 text-blue-400" />
          <h2 className="text-lg font-semibold text-white">Bigger Workspace</h2>
          <span className="text-sm text-gray-400">Large canvas for complex and large diagrams and flowcharts</span>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={clearCanvas}
            className="flex items-center space-x-2 text-gray-400 hover:text-white px-3 py-1.5 rounded transition-colors border border-gray-600 hover:border-gray-500"
            title="Clear Canvas"
          >
            <RotateCcw className="w-4 h-4" />
            <span className="text-sm">Clear</span>
          </button>
          <button
            onClick={downloadCanvas}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded transition-colors"
            title="Download Canvas"
          >
            <Download className="w-4 h-4" />
            <span className="text-sm">Download</span>
          </button>
        </div>
      </div>

      {/* Enhanced Toolbar */}
      <div className="p-4 bg-gray-800 border-b border-gray-700">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Tools */}
          <div className="flex items-center space-x-3">
            <span className="text-sm font-medium text-gray-300 w-16">Tools:</span>
            <div className="flex space-x-2">
              {[
                { type: 'pen' as const, icon: Pen, label: 'Pen' },
                { type: 'eraser' as const, icon: Eraser, label: 'Eraser' },
              ].map(({ type, icon: Icon, label }) => (
                <button
                  key={type}
                  onClick={() => setTool(prev => ({ ...prev, type }))}
                  className={`flex items-center space-x-2 px-3 py-2 rounded text-sm transition-colors ${
                    tool.type === type
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                  title={label}
                >
                  <Icon className="w-4 h-4" />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Size */}
          <div className="flex items-center space-x-3">
            <span className="text-sm font-medium text-gray-300 w-16">Size:</span>
            <input
              type="range"
              min="1"
              max="30"
              value={tool.size}
              onChange={(e) => setTool(prev => ({ ...prev, size: parseInt(e.target.value) }))}
              className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-sm text-gray-400 w-8 text-center">{tool.size}px</span>
          </div>

          {/* Colors */}
          <div className="flex items-center space-x-3">
            <span className="text-sm font-medium text-gray-300 w-16">Color:</span>
            <div className="flex flex-wrap gap-2">
              {colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setTool(prev => ({ ...prev, color }))}
                  className={`w-8 h-8 rounded-full border-2 transition-all hover:scale-110 ${
                    tool.color === color ? 'border-blue-400 scale-110' : 'border-gray-600'
                  }`}
                  style={{ backgroundColor: color }}
                  title={color}
                />
              ))}
              <input
                type="color"
                value={tool.color}
                onChange={(e) => setTool(prev => ({ ...prev, color: e.target.value }))}
                className="w-8 h-8 rounded-full border-2 border-gray-600 cursor-pointer"
                title="Custom Color"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Large Canvas */}
      <div className="relative bg-gray-800">
        <canvas
          ref={canvasRef}
          className="w-full cursor-crosshair"
          style={{ height: '600px' }}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
        />
        
        {/* Grid overlay for better alignment */}
        <div className="absolute inset-0 pointer-events-none opacity-10">
          <svg className="w-full h-full">
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#374151" strokeWidth="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>
      </div>

      {/* Usage Tips */}
      <div className="p-4 bg-gray-800 border-t border-gray-700">
        <div className="flex items-center justify-center space-x-8 text-sm text-gray-400">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
            <span>Perfect for algorithm flowcharts</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span>Draw data structures and trees</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
            <span>Sketch problem-solving approaches</span>
          </div>
        </div>
      </div>
    </div>
  );
}