import React from 'react';
import { Terminal, AlertCircle, CheckCircle } from 'lucide-react';

interface OutputPanelProps {
  output: string;
  error: string;
  isExecuting: boolean;
  executionTime?: number;
}

export default function OutputPanel({ output, error, isExecuting, executionTime }: OutputPanelProps) {
  const hasError = error && error.trim() !== '';
  const hasOutput = output && output.trim() !== '';

  return (
    <div className="flex flex-col h-full bg-gray-900 border border-gray-700 rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-3 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <Terminal className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-300">Output</span>
        </div>
        {executionTime && (
          <span className="text-xs text-gray-400">
            Executed in {executionTime}ms
          </span>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 p-4 overflow-auto">
        {isExecuting ? (
          <div className="flex items-center space-x-2 text-yellow-400">
            <div className="animate-spin w-4 h-4 border-2 border-yellow-400 border-t-transparent rounded-full"></div>
            <span className="text-sm">Executing code...</span>
          </div>
        ) : (
          <div className="space-y-4">
            {hasError && (
              <div className="bg-red-900/30 border border-red-700 rounded p-3">
                <div className="flex items-center space-x-2 mb-2">
                  <AlertCircle className="w-4 h-4 text-red-400" />
                  <span className="text-sm font-medium text-red-400">Error</span>
                </div>
                <pre className="text-sm text-red-300 whitespace-pre-wrap font-mono">
                  {error}
                </pre>
              </div>
            )}
            
            {hasOutput && (
              <div className="bg-green-900/20 border border-green-700 rounded p-3">
                <div className="flex items-center space-x-2 mb-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-sm font-medium text-green-400">Output</span>
                </div>
                <pre className="text-sm text-gray-300 whitespace-pre-wrap font-mono">
                  {output}
                </pre>
              </div>
            )}
            
            {!hasError && !hasOutput && !isExecuting && (
              <div className="text-center text-gray-500 py-8">
                <Terminal className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Run your code to see output here</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}