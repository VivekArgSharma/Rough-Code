import { Language, ExecutionResult } from '../types';

const PISTON_API_URL = 'https://emkc.org/api/v2/piston';

export const languages: Language[] = [
  {
    id: 'javascript',
    name: 'JavaScript',
    version: '18.15.0',
    extension: 'js',
    template: 'console.log("Hello, World!");'
  },
  {
    id: 'python',
    name: 'Python',
    version: '3.10.0',
    extension: 'py',
    template: 'print("Hello, World!")'
  },
  {
    id: 'java',
    name: 'Java',
    version: '15.0.2',
    extension: 'java',
    template: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}`
  },
  {
    id: 'cpp',
    name: 'C++',
    version: '10.2.0',
    extension: 'cpp',
    template: `#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}`
  },
  {
    id: 'c',
    name: 'C',
    version: '10.2.0',
    extension: 'c',
    template: `#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}`
  },
  {
    id: 'go',
    name: 'Go',
    version: '1.16.2',
    extension: 'go',
    template: `package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
}`
  }
];

export async function executeCode(language: string, version: string, code: string): Promise<ExecutionResult> {
  try {
    const response = await fetch(`${PISTON_API_URL}/execute`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        language: language,
        version: version,
        files: [
          {
            content: code,
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error executing code:', error);
    return {
      run: {
        output: '',
        stderr: `Error: ${error instanceof Error ? error.message : 'Unknown error occurred'}`,
        code: 1,
      },
    };
  }
}