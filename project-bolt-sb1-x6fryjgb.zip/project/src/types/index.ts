export interface Language {
  id: string;
  name: string;
  version: string;
  extension: string;
  template: string;
}

export interface ExecutionResult {
  run: {
    output: string;
    stderr: string;
    code: number;
  };
}

export interface DrawingTool {
  type: 'pen' | 'eraser' | 'rectangle' | 'circle' | 'line';
  size: number;
  color: string;
}